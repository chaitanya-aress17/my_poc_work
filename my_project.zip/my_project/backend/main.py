from fastapi import FastAPI, HTTPException, UploadFile, File
from pydantic import BaseModel
from typing import List
import pandas as pd
import os
from lida import Manager, TextGenerationConfig, llm
from lida.datamodel import Goal
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

# Create data directory if it doesn't exist
os.makedirs("data", exist_ok=True)

class TextGenerationConfigModel(BaseModel):
    n: int
    temperature: float
    model: str
    use_cache: bool

class GoalModel(BaseModel):
    question: str
    visualization: str
    rationale: str

def get_openai_key():
    openai_key = os.getenv("COHERE_API_KEY")
    if not openai_key:
        raise HTTPException(status_code=400, detail="API key is missing")
    return openai_key

@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    file_location = f"data/{file.filename}"
    with open(file_location, "wb") as buffer:
        buffer.write(file.file.read())
    return {"filename": file.filename}
dataset_path="backend\data\healthcare_dataset.csv"
@app.post("/summarize/")
async def summarize_data(dataset_path: str, summary_method: str, textgen_config: TextGenerationConfigModel):
    openai_key = get_openai_key()
    lida = Manager(text_gen=llm("cohere", api_key=openai_key))
    config = TextGenerationConfig(
        n=textgen_config.n,
        temperature=textgen_config.temperature,
        model=textgen_config.model,
        use_cache=textgen_config.use_cache
    )
    summary = lida.summarize(dataset_path, summary_method=summary_method, textgen_config=config)
    return summary

@app.post("/generate-goals/")
async def generate_goals(dataset_path: str, summary_method: str, num_goals: int, textgen_config: TextGenerationConfigModel):
    openai_key = get_openai_key()
    lida = Manager(text_gen=llm("cohere", api_key=openai_key))
    config = TextGenerationConfig(
        n=textgen_config.n,
        temperature=textgen_config.temperature,
        model=textgen_config.model,
        use_cache=textgen_config.use_cache
    )
    summary = lida.summarize(dataset_path, summary_method=summary_method, textgen_config=config)
    goals = lida.goals(summary, n=num_goals, textgen_config=config)
    return goals

@app.post("/visualize/")
async def visualize_data(dataset_path: str, goal: GoalModel, textgen_config: TextGenerationConfigModel, library: str):
    openai_key = get_openai_key()
    lida = Manager(text_gen=llm("cohere", api_key=openai_key))
    config = TextGenerationConfig(
        n=textgen_config.n,
        temperature=textgen_config.temperature,
        model=textgen_config.model,
        use_cache=textgen_config.use_cache
    )
    summary = lida.summarize(dataset_path, summary_method="default", textgen_config=config)
    visualizations = lida.visualize(summary=summary, goal=goal, textgen_config=config, library=library)
    return visualizations

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
