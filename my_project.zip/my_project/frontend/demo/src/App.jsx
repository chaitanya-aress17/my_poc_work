import React from 'react';
import { Routes, Route } from 'react-router-dom';
import FileUpload from './components/FileUpload';
import Summarize from './components/Summarize';
import GenerateGoals from './components/GenerateGoals';
import Visualize from './components/Visualize';

function App() {
  return (
    <Routes>
      <Route path="/" element={<FileUpload />} />
      <Route path="/summarize" element={<Summarize />} />
      <Route path="/generate-goals" element={<GenerateGoals />} />
      <Route path="/visualize" element={<Visualize />} />
    </Routes>
  );
}

export default App;

