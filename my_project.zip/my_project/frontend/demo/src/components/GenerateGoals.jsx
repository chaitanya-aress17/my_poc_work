import React, { useState } from 'react';
import axios from 'axios';

function GenerateGoals() {
  const [datasetPath, setDatasetPath] = useState('');
  const [summaryMethod, setSummaryMethod] = useState('');
  const [numGoals, setNumGoals] = useState(1);
  const [textgenConfig, setTextgenConfig] = useState({ n: 1, temperature: 0.7, model: 'base-xlarge', use_cache: false });
  const [goals, setGoals] = useState([]);

  const generateGoals = async () => {
    try {
      const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/generate-goals/`, {
        dataset_path: datasetPath,
        summary_method: summaryMethod,
        num_goals: numGoals,
        textgen_config: textgenConfig
      });
      setGoals(response.data);
    } catch (error) {
      alert('Error generating goals');
    }
  };

  return (
    <div>
      <h1>Generate Goals</h1>
      <input type="text" placeholder="Dataset Path" onChange={(e) => setDatasetPath(e.target.value)} />
      <input type="text" placeholder="Summary Method" onChange={(e) => setSummaryMethod(e.target.value)} />
      <input type="number" placeholder="Number of Goals" onChange={(e) => setNumGoals(e.target.value)} />
      <button onClick={generateGoals}>Generate Goals</button>
      <ul>
        {goals.map((goal, index) => (
          <li key={index}>{goal.question}</li>
        ))}
      </ul>
    </div>
  );
}

export default GenerateGoals;
