import React, { useState } from 'react';
import axios from 'axios';

function Summarize() {
  const [datasetPath, setDatasetPath] = useState('');
  const [summaryMethod, setSummaryMethod] = useState('');
  const [textgenConfig, setTextgenConfig] = useState({ n: 1, temperature: 0.7, model: 'base-xlarge', use_cache: false });
  const [summary, setSummary] = useState('');

  const summarizeData = async () => {
    try {
      const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/summarize/`, {
        dataset_path: datasetPath,
        summary_method: summaryMethod,
        textgen_config: textgenConfig
      });
      setSummary(response.data);
    } catch (error) {
      alert('Error summarizing data');
    }
  };

  return (
    <div>
      <h1>Summarize Data</h1>
      <input type="text" placeholder="Dataset Path" onChange={(e) => setDatasetPath(e.target.value)} />
      <input type="text" placeholder="Summary Method" onChange={(e) => setSummaryMethod(e.target.value)} />
      <button onClick={summarizeData}>Summarize</button>
      <pre>{JSON.stringify(summary, null, 2)}</pre>
    </div>
  );
}

export default Summarize;
