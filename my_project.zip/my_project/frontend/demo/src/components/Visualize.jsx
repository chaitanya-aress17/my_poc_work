import React, { useState } from 'react';
import axios from 'axios';

function Visualize() {
  const [datasetPath, setDatasetPath] = useState('');
  const [goal, setGoal] = useState('');
  const [textgenConfig, setTextgenConfig] = useState({ n: 1, temperature: 0.7, model: 'base-xlarge', use_cache: false });
  const [library, setLibrary] = useState('seaborn');
  const [visualizations, setVisualizations] = useState([]);

  const visualizeData = async () => {
    try {
      const response = await axios.post(`${process.env.REACT_APP_BACKEND_URL}/visualize/`, {
        dataset_path: datasetPath,
        goal: { question: goal, visualization: goal, rationale: '' },
        textgen_config: textgenConfig,
        library: library
      });
      setVisualizations(response.data);
    } catch (error) {
      alert('Error visualizing data');
    }
  };

  return (
    <div>
      <h1>Visualize Data</h1>
      <input type="text" placeholder="Dataset Path" onChange={(e) => setDatasetPath(e.target.value)} />
      <input type="text" placeholder="Goal" onChange={(e) => setGoal(e.target.value)} />
      <input type="text" placeholder="Library" onChange={(e) => setLibrary(e.target.value)} />
      <button onClick={visualizeData}>Visualize</button>
      <div>
        {visualizations.map((viz, index) => (
          <div key={index}>
            <h3>Visualization {index + 1}</h3>
            <pre>{viz.code}</pre>
            {viz.raster && <img src={`data:image/png;base64,${viz.raster}`} alt={`Visualization ${index + 1}`} />}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Visualize;
